jQuery.noConflict();
var CommerceLab = {};