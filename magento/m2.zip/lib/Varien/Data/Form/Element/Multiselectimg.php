<?php
/**
* @author Amasty Team
* @copyright Amasty
* @package Amasty_Customerattr
*/
class Varien_Data_Form_Element_Multiselectimg extends Amasty_Customerattr_Block_Data_Form_Element_Multiselectimg
{

}